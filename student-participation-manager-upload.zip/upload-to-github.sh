#!/bin/bash

echo "🚀 学生参与管理器 - GitHub 上传脚本"
echo "=================================="

# 检查是否在正确的目录
if [ ! -f "package.json" ]; then
    echo "❌ 错误: 请在项目根目录运行此脚本"
    exit 1
fi

echo "📦 准备上传文件到 GitHub..."

# 创建上传包，排除不需要的文件
echo "🗂️  创建上传包..."
zip -r student-participation-manager-upload.zip . \
    -x "node_modules/*" \
    -x "dist/*" \
    -x "build/*" \
    -x ".git/*" \
    -x "*.log" \
    -x ".DS_Store" \
    -x "student-participation-manager-upload.zip"

if [ $? -eq 0 ]; then
    echo "✅ 上传包创建成功: student-participation-manager-upload.zip"
    echo ""
    echo "📋 接下来的步骤:"
    echo "1. 访问 https://github.com 创建新仓库"
    echo "2. 仓库名称: student-participation-manager"
    echo "3. 设置为 Public (公开)"
    echo "4. 上传 student-participation-manager-upload.zip 文件"
    echo "5. 等待 GitHub Actions 自动构建 (约15分钟)"
    echo "6. 从 Releases 页面下载 .dmg 文件"
    echo ""
    echo "📁 上传包位置: $(pwd)/student-participation-manager-upload.zip"
    echo "📏 文件大小: $(du -h student-participation-manager-upload.zip | cut -f1)"
    echo ""
    echo "🎯 提示: 解压后上传所有文件，或直接上传 zip 文件到 GitHub"
else
    echo "❌ 创建上传包失败"
    exit 1
fi
