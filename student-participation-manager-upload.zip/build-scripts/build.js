const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 开始构建学生参与管理器...');

try {
  // 检查 Node.js 版本
  const nodeVersion = process.version;
  console.log(`📋 Node.js 版本: ${nodeVersion}`);

  // 安装依赖
  console.log('📦 安装依赖...');
  execSync('npm install', { stdio: 'inherit' });

  // 构建 React 应用
  console.log('🔨 构建 React 应用...');
  execSync('npm run build', { stdio: 'inherit' });

  // 检查构建结果
  const buildPath = path.join(__dirname, '..', 'build');
  if (fs.existsSync(buildPath)) {
    console.log('✅ React 应用构建成功');
  } else {
    throw new Error('React 应用构建失败');
  }

  console.log('🎉 构建完成！');
  console.log('');
  console.log('📖 接下来的步骤:');
  console.log('1. 运行 "npm run electron-dev" 进行开发测试');
  console.log('2. 运行 "npm run dist" 生成可执行文件');
  console.log('');

} catch (error) {
  console.error('❌ 构建失败:', error.message);
  process.exit(1);
}
